highstock-beyond-extremes
=========================

Highstock plugin for allowing the input range dates to be beyond the range of the current data in the chart.

The contents of the plugin is located in the javascript file "beyond-extremes.js". This plugin is published under the MIT license, and the license document is included in the repository.

Usage
=====
1. Include the plugin after Highstock
2. Add `beyondExtremes: true` to the "rangeSelector" object in your chart options
